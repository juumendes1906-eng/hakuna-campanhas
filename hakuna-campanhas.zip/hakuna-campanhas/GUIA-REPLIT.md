# 🚀 Guia de Deploy — Hakuna Campanhas no Replit

## O que você vai ter no final
Um link fixo (ex: hakuna-campanhas.seuusuario.repl.co) que qualquer pessoa
da equipe acessa pelo celular ou computador, conectado ao RD Station em tempo real.

---

## PASSO 1 — Criar conta no Replit (grátis)
1. Acesse https://replit.com
2. Clique em "Sign up"
3. Crie com Google ou e-mail

---

## PASSO 2 — Criar o projeto
1. Clique em **"+ Create Repl"**
2. Escolha template: **Node.js**
3. Nome do projeto: `hakuna-campanhas`
4. Clique em **"Create Repl"**

---

## PASSO 3 — Subir os arquivos

Você vai ver uma estrutura de arquivos na esquerda. Faça o seguinte:

### Arquivo 1: `server.js`
- Clique no arquivo `index.js` que já existe
- Renomeie para `server.js` (clique com botão direito → Rename)
- Apague todo o conteúdo e cole o conteúdo do arquivo `server.js`

### Arquivo 2: pasta `public`
- Clique em **"New Folder"** e crie a pasta `public`
- Dentro dela, clique em **"New File"** → `index.html`
- Cole o conteúdo do arquivo `public/index.html`

### Arquivo 3: `package.json`
- Clique no `package.json` já existente
- Substitua o conteúdo pelo do arquivo `package.json` fornecido

---

## PASSO 4 — Instalar dependências
No terminal do Replit (aba "Shell" na parte de baixo), digite:
```
npm install
```
Aguarde instalar express, node-fetch e cors.

---

## PASSO 5 — Rodar
Clique no botão verde **"Run"** no topo.

Você vai ver no terminal:
```
Hakuna Campanhas rodando na porta 3000
```

O Replit vai abrir uma janela de preview com o sistema funcionando!

---

## PASSO 6 — Pegar o link fixo
1. Na janela de preview, clique em **"Open in new tab"** (ícone de janela)
2. Copie a URL — é o seu link permanente
3. Compartilhe com a equipe!

---

## PASSO 7 — Conectar o RD Station
No sistema já no ar:
1. Cole a **API Key do RD Marketing** no campo correspondente
2. Cole a **API Key do RD CRM** no campo correspondente
3. Clique em **"Conectar"**
4. Pronto — leads, pedidos e ranking aparecem em tempo real!

---

## Onde ficam as API Keys do RD?

**RD Marketing:**
- Acesse app.rdstation.com.br
- Menu superior direito → Integrações → API → Token de API

**RD CRM:**
- Acesse crm.rdstation.com
- Configurações → Integrações → Token de API

---

## Mantendo o sistema sempre no ar (importante!)
O Replit gratuito "dorme" após inatividade. Para manter sempre ligado:
- Crie conta em https://uptimerobot.com (grátis)
- Adicione um monitor HTTP para a URL do seu Repl
- Isso faz um ping a cada 5 minutos e mantém o sistema acordado

---

## Deu algum erro?
Me manda print que resolvo na hora! 💪
