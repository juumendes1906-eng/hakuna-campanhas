const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── RD MARKETING: Leads do mês ───────────────────────────────────────────
app.get('/api/rd/leads', async (req, res) => {
  const key = req.headers['x-rd-mkt-key'];
  if (!key) return res.status(400).json({ error: 'API key não informada' });

  try {
    const hoje = new Date();
    const inicioMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1).toISOString();

    const r = await fetch(
      `https://api.rd.services/platform/contacts?page_size=200&order=created_at&sort=desc`,
      { headers: { 'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json' } }
    );

    if (!r.ok) {
      const err = await r.text();
      return res.status(r.status).json({ error: 'Erro RD Marketing', detail: err });
    }

    const data = await r.json();
    const contacts = data.contacts || [];

    // Filtra leads criados neste mês
    const leadsDoMes = contacts.filter(c => {
      const criado = new Date(c.created_at);
      return criado >= new Date(inicioMes);
    });

    res.json({
      total_mes: leadsDoMes.length,
      total_geral: data.total || contacts.length
    });

  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── RD CRM: Oportunidades abertas ────────────────────────────────────────
app.get('/api/rd/oportunidades', async (req, res) => {
  const key = req.headers['x-rd-crm-key'];
  if (!key) return res.status(400).json({ error: 'API key não informada' });

  try {
    const r = await fetch(
      `https://crm.rdstation.com/api/v1/deals?page=1&limit=200`,
      { headers: { 'token': key } }
    );

    if (!r.ok) {
      const err = await r.text();
      return res.status(r.status).json({ error: 'Erro RD CRM', detail: err });
    }

    const data = await r.json();
    const deals = data.deals || [];

    const abertas = deals.filter(d => !d.win && !d.lost);
    const ganhas  = deals.filter(d => d.win);

    res.json({
      abertas: abertas.length,
      ganhas:  ganhas.length,
      total:   deals.length
    });

  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── RD CRM: Pedidos fechados (won) + Ranking ─────────────────────────────
app.get('/api/rd/fechados', async (req, res) => {
  const key    = req.headers['x-rd-crm-key'];
  const period = req.query.period || 'semana'; // semana | mes
  if (!key) return res.status(400).json({ error: 'API key não informada' });

  try {
    // Calcula janela de data
    const hoje = new Date(); hoje.setHours(23,59,59,999);
    const inicio = new Date();
    if (period === 'semana') {
      inicio.setDate(hoje.getDate() - 6);
    } else {
      inicio.setDate(1);
    }
    inicio.setHours(0,0,0,0);

    // Busca múltiplas páginas
    let page = 1, allDeals = [];
    while (true) {
      const r = await fetch(
        `https://crm.rdstation.com/api/v1/deals?page=${page}&limit=200&win=true`,
        { headers: { 'token': key } }
      );
      if (!r.ok) break;
      const data = await r.json();
      const deals = data.deals || [];
      if (!deals.length) break;
      allDeals = allDeals.concat(deals);
      if (deals.length < 200) break;
      page++;
      if (page > 10) break; // segurança
    }

    // Filtra pelo período
    const filtrados = allDeals.filter(d => {
      const closedAt = d.closed_at ? new Date(d.closed_at) : new Date(d.updated_at);
      return closedAt >= inicio && closedAt <= hoje;
    });

    // Monta ranking por vendedor
    const porVendedor = {};
    filtrados.forEach(deal => {
      const nome   = deal.user?.name || 'Sem responsável';
      const equipe = deal.campaign?.name || deal.deal_source?.name || '—';
      if (!porVendedor[nome]) {
        porVendedor[nome] = { nome, equipe, pedidos: 0, valor: 0 };
      }
      porVendedor[nome].pedidos++;
      porVendedor[nome].valor += parseFloat(deal.amount_montly || deal.amount || 0);
    });

    const ranking = Object.values(porVendedor)
      .sort((a, b) => b.pedidos - a.pedidos || b.valor - a.valor);

    const valorTotal = filtrados.reduce((acc, d) =>
      acc + parseFloat(d.amount_montly || d.amount || 0), 0);

    res.json({
      total_pedidos: filtrados.length,
      valor_total:   valorTotal,
      periodo:       period,
      ranking
    });

  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── Saúde do servidor ────────────────────────────────────────────────────
app.get('/api/ping', (_, res) => res.json({ ok: true, ts: new Date().toISOString() }));

// ─── Inicia ───────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Hakuna Campanhas rodando na porta ${PORT}`));
